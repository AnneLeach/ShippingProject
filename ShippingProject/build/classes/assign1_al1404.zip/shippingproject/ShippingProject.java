package shippingproject;
import java.io.IOException;

/**
 * This main class is the hub from which a shipping employee may view,
 * add, delete, print, and search a database of shipping items.
 * @author Anne
 */
public class ShippingProject {
    public static void main(String[] args) throws IOException{
        /**Holds text file name.*/
        final String FILE_NAME = "packages.txt";
        /**Holds user's menu choice.*/
        int menuCommand;
        ProcessFile itemsFile = new ProcessFile(FILE_NAME);  
        ItemArray arrayOb = new ItemArray();  
        /**Loads array*/
        arrayOb.loadArray(FILE_NAME);  
        /**Menu object to validate and execute user choice.*/
        Menu menuOb = new Menu(); 
        /**This object holds the array in which data will be manipulated.*/
        UniqueItem itemOb = new UniqueItem();  
        //********************************************************BODY
        menuOb.printMenu();
        menuCommand = menuOb.getCommand();
        do{
            if (menuCommand == 1){
                arrayOb.printArray();
                menuOb.printMenu();
                menuCommand = menuOb.getCommand();
            }
            if (menuCommand == 2){
                itemOb = new UniqueItem(1); //1 -> distinguish user input.
                arrayOb.addItem(itemOb);  
                menuOb.printMenu();
                menuCommand = menuOb.getCommand();              
            }
            if (menuCommand == 3){
                arrayOb.deleteItem();
                menuOb.printMenu();
                menuCommand = menuOb.getCommand();              
            }
            if (menuCommand == 4){
                arrayOb.searchItem();
                menuOb.printMenu();
                menuCommand = menuOb.getCommand();               
            }
            if (menuCommand == 5){
                arrayOb.searchWeight();
                menuOb.printMenu();
                menuCommand = menuOb.getCommand();               
            }                     
        }while(menuCommand != 6);
 
        itemsFile.overwriteFile(arrayOb);  //Overwrites text file.
        System.out.print("\n\nThank you.  Goodbye.");
        System.out.print("\n\n");     
    }
    
}
