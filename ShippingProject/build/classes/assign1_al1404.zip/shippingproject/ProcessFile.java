package shippingproject;
import java.io.IOException;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.ArrayList;

/**
 * Manages opening, reading, overwriting new or existing files. 
 */
public class ProcessFile{
    /**
     * Holds name of file, ex) "packages.txt"
     */
    private String fileName;
    /**
     * Auto open/create file with provided name.
     */
    public ProcessFile(String newName) throws IOException{
        fileName = newName;
        
        File itemsFile = new File(fileName);
        if(!itemsFile.exists()){
            System.out.print("\nT: " + fileName + " does not exist.  Creating now.");    
            PrintWriter pw = new PrintWriter(fileName);
            pw.close();
        }
        else{
            System.out.print("\nT: " + fileName + " file found.  Opening now.");       
        }
    }
    /**
     * Upon closing program, overwrites existing file.
     * @param arrayOb Sends array of shipping items.
     * @throws IOException 
     */
    public void overwriteFile(ItemArray arrayOb) throws IOException{
        
        PrintWriter outFile = new PrintWriter(fileName);
        ArrayList<UniqueItem> temp = new ArrayList<UniqueItem>();
        temp = arrayOb.getArray();
        
        for(int k = 0; k < temp.size(); k++){
            outFile.println( (temp.get(k)).returnStringLine() );
        }
        outFile.close();
    }
}
