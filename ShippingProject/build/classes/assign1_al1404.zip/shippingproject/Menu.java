package shippingproject;
import java.util.Scanner;
/**
 * Prints menu, validates choice, & sends out commands.
 * @author Anne
 */
public class Menu {
    /**
     * Holds user's choice.  Validated before released to main.
     */
    private int command;
    /**
     * It prints a menu of options to the user.
     */
    public void printMenu(){        
        System.out.print("\n\nWelcome to the ShipperQuicker 3000"
                + "\nPlease enter your command:"
                + "\n\n1.  View all records currently in database."
                + "\n2.  Add new package record."
                + "\n3.  Delete package record."
                + "\n4.  Search for a package."
                + "\n5.  Find packages within a weight range."
                + "\n6.  Exit."
                +"\n\n--->  ");
    }  
    /**
     * Accepts user menu choice, and validates it.
     * @return Validated user choice.
     */
    public int getCommand(){
        Scanner menuScan = new Scanner(System.in);
        String temp = menuScan.nextLine();
        
        while (!temp.equals("1") && !temp.equals("2") && !temp.equals("3")
                && !temp.equals("4") && !temp.equals("5") && !temp.equals("6")){
            System.out.print("\nPlease enter a valid number (1 - 6) --->  ");
            temp = menuScan.nextLine();
        }
        command = Integer.parseInt(temp);
        return command;
    }
}
